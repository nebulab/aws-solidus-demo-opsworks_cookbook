default['s3_file']['mime-types']['version'] = '2.6.2'
default['s3_file']['rest-client']['version'] = '1.7.3'
