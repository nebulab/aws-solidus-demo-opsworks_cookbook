#
# Cookbook:: build_cookbook
# Recipe:: publish
#
# Copyright:: 2019, The Authors, All Rights Reserved.
include_recipe 'delivery-truck::publish'
